<?php 

class Constants {

    const DEFAULT_IMAGE = 0;
    const YT_VIDEO = 1;
    const LOCAL_VIDEO = 2;
    const LOCAL_IMAGE = 3;


}