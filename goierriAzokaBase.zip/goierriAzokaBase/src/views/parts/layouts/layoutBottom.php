<br>
<?php

require_once(APP_DIR  . '/src/views/parts/footer.php');

require_once(APP_DIR  . '/src/views/parts/scripts.php');

?>

</body>

</html>