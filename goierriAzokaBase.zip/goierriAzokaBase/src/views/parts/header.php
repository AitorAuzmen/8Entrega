<div class="header">

    <div>
        <img class="header-elem-left" src="<?= HREF_APP_DIR ?>/public/goierriEskola.jpg" alt="goierriEskola">
    </div>
    <div class="flex-center">
            <div class="rightSidebar header-elem-right" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" aria-controls="offcanvasRight">
                <div><span class="sidebar-text">Gune guztiak ikusi</span> ☰</div>
            </div>
    </div>
</div>

<?php 

//Constants
require_once(APP_DIR . '/src/php/constants.php');

?>